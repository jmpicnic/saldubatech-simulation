create function search_results_insert_trigger() returns trigger
  language plpgsql
as
$$
BEGIN
        IF (NEW.created_at >= '2018-11-01'::date AND NEW.created_at < '2018-12-01'::date) THEN
            INSERT INTO search_results_201811 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-12-01'::date AND NEW.created_at < '2019-01-01'::date) THEN
            INSERT INTO search_results_201812 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2019-01-01'::date AND NEW.created_at < '2019-02-01'::date) THEN
            INSERT INTO search_results_201901 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2019-02-01'::date AND NEW.created_at < '2019-03-01'::date) THEN
            INSERT INTO search_results_201902 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-10-01'::date AND NEW.created_at < '2018-11-01'::date) THEN
            INSERT INTO search_results_201810 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-09-01'::date AND NEW.created_at < '2018-10-01'::date) THEN
            INSERT INTO search_results_201809 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-08-01'::date AND NEW.created_at < '2018-09-01'::date) THEN
            INSERT INTO search_results_201808 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-07-01'::date AND NEW.created_at < '2018-08-01'::date) THEN
            INSERT INTO search_results_201807 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-06-01'::date AND NEW.created_at < '2018-07-01'::date) THEN
            INSERT INTO search_results_201806 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-05-01'::date AND NEW.created_at < '2018-06-01'::date) THEN
            INSERT INTO search_results_201805 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-04-01'::date AND NEW.created_at < '2018-05-01'::date) THEN
            INSERT INTO search_results_201804 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-03-01'::date AND NEW.created_at < '2018-04-01'::date) THEN
            INSERT INTO search_results_201803 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-02-01'::date AND NEW.created_at < '2018-03-01'::date) THEN
            INSERT INTO search_results_201802 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2018-01-01'::date AND NEW.created_at < '2018-02-01'::date) THEN
            INSERT INTO search_results_201801 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-12-01'::date AND NEW.created_at < '2018-01-01'::date) THEN
            INSERT INTO search_results_201712 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-11-01'::date AND NEW.created_at < '2017-12-01'::date) THEN
            INSERT INTO search_results_201711 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-10-01'::date AND NEW.created_at < '2017-11-01'::date) THEN
            INSERT INTO search_results_201710 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-09-01'::date AND NEW.created_at < '2017-10-01'::date) THEN
            INSERT INTO search_results_201709 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-08-01'::date AND NEW.created_at < '2017-09-01'::date) THEN
            INSERT INTO search_results_201708 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-07-01'::date AND NEW.created_at < '2017-08-01'::date) THEN
            INSERT INTO search_results_201707 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-06-01'::date AND NEW.created_at < '2017-07-01'::date) THEN
            INSERT INTO search_results_201706 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-05-01'::date AND NEW.created_at < '2017-06-01'::date) THEN
            INSERT INTO search_results_201705 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-04-01'::date AND NEW.created_at < '2017-05-01'::date) THEN
            INSERT INTO search_results_201704 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-03-01'::date AND NEW.created_at < '2017-04-01'::date) THEN
            INSERT INTO search_results_201703 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-02-01'::date AND NEW.created_at < '2017-03-01'::date) THEN
            INSERT INTO search_results_201702 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2017-01-01'::date AND NEW.created_at < '2017-02-01'::date) THEN
            INSERT INTO search_results_201701 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-12-01'::date AND NEW.created_at < '2017-01-01'::date) THEN
            INSERT INTO search_results_201612 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-11-01'::date AND NEW.created_at < '2016-12-01'::date) THEN
            INSERT INTO search_results_201611 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-10-01'::date AND NEW.created_at < '2016-11-01'::date) THEN
            INSERT INTO search_results_201610 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-09-01'::date AND NEW.created_at < '2016-10-01'::date) THEN
            INSERT INTO search_results_201609 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-08-01'::date AND NEW.created_at < '2016-09-01'::date) THEN
            INSERT INTO search_results_201608 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-07-01'::date AND NEW.created_at < '2016-08-01'::date) THEN
            INSERT INTO search_results_201607 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-06-01'::date AND NEW.created_at < '2016-07-01'::date) THEN
            INSERT INTO search_results_201606 VALUES (NEW.*);
        ELSIF (NEW.created_at >= '2016-05-01'::date AND NEW.created_at < '2016-06-01'::date) THEN
            INSERT INTO search_results_201605 VALUES (NEW.*);
        ELSE
            RAISE EXCEPTION 'Date out of range. Ensure partitions are created.';
        END IF;
        RETURN NULL;
    END;
$$;

alter function search_results_insert_trigger() owner to postgres;

